// @ts-check
/**
 * Notes where you point, click and which shortcuts you press, only while a Dotfik Studio recording is
 * running, and hands them to the studio tab on this computer. Password and card fields are never
 * read. With "shortcuts only" (the default), ordinary typing is ignored entirely.
 */
(() => {
  const DEFAULT_PORTS = /** @type {Record<string, string>} */ ({ 'http:': '80', 'https:': '443' });

  /** @param {string} text */
  const escapeRegExp = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  /** @param {string} scheme @param {string} protocol */
  const schemeMatches = (scheme, protocol) => (scheme === '*' ? protocol === 'http:' || protocol === 'https:' : protocol === `${scheme}:`);

  /** @param {string} host Exact, "*" for any, or "*.example.com" for that domain and all below it. @param {string} hostname */
  const hostMatches = (host, hostname) => {
    if (host === '*') return true;
    if (!host.startsWith('*.')) return hostname === host;
    const domain = host.slice(2);
    return hostname === domain || hostname.endsWith(`.${domain}`);
  };

  /** @param {string} port "*" (also when the pattern names none) or a number. @param {URL} url */
  const portMatches = (port, url) => port === '*' || Number(port) === Number(url.port || DEFAULT_PORTS[url.protocol]);

  /** @param {string} path A pattern's path, where * stands for anything. @param {string} value */
  const pathMatches = (path, value) => new RegExp(`^${path.split('*').map(escapeRegExp).join('.*')}$`).test(value);

  /**
   * Whether an address matches a Chrome match pattern such as "https://*.example.com/*". As in
   * Chrome, a pattern without a port matches every port, and the path includes the query.
   * @param {string} pattern
   * @param {URL} url
   */
  const matchesPattern = (pattern, url) => {
    if (pattern === '<all_urls>') return true;
    const parts = /^(\*|[a-z][a-z0-9+.-]*):\/\/(\[[^\]]*\]|[^/:]*)(?::(\*|\d+))?(\/.*)$/i.exec(pattern);
    if (!parts) return false;
    const [, scheme = '', host = '', port = '*', path = ''] = parts;
    return (
      schemeMatches(scheme.toLowerCase(), url.protocol) &&
      hostMatches(host.toLowerCase(), url.hostname) &&
      portMatches(port, url) &&
      pathMatches(path, url.pathname + url.search)
    );
  };

  /** The studio's own pages (where the bridge script runs) are the recorder, never what's recorded. */
  const isStudioPage = () => {
    const patterns = chrome.runtime.getManifest().content_scripts?.find((script) => script.js?.includes('bridge.js'))?.matches ?? [];
    const url = new URL(location.href);
    return patterns.some((pattern) => matchesPattern(pattern, url));
  };

  if (isStudioPage()) return;
  const scope = /** @type {typeof globalThis & { __dotfikCapture?: boolean }} */ (globalThis);
  if (scope.__dotfikCapture) return;
  scope.__dotfikCapture = true;

  const MOVE_INTERVAL_MS = 1000 / 60;
  const FLUSH_MS = 50;
  const MAXIMUM_BATCH = 500;
  const MODIFIER_KEYS = new Set(['Shift', 'Control', 'Alt', 'Meta', 'CapsLock', 'Fn', 'FnLock', 'Hyper', 'Super', 'OS']);
  const isTopFrame = window === window.top;

  let isActive = false;
  /** @type {'off' | 'shortcutsOnly' | 'allKeys'} */
  let keystrokes = 'shortcutsOnly';
  /** The newest news about the recording heard so far: older news arriving late is ignored. */
  let revision = -Infinity;
  /** @type {unknown[]} */
  let queue = [];
  /** @type {ReturnType<typeof setTimeout> | 0} */
  let timer = 0;
  let lastMove = -Infinity;

  /** @param {Event} event */
  const unixTime = (event) => performance.timeOrigin + event.timeStamp;

  const geometry = () => {
    const extended = /** @type {{ isExtended?: boolean, availLeft?: number, availTop?: number }} */ (screen);
    return {
      innerWidth: window.innerWidth,
      innerHeight: window.innerHeight,
      outerWidth: window.outerWidth,
      outerHeight: window.outerHeight,
      windowX: window.screenX,
      windowY: window.screenY,
      screenWidth: screen.width,
      screenHeight: screen.height,
      screenLeft: extended.isExtended ? (extended.availLeft ?? 0) : 0,
      screenTop: extended.isExtended ? (extended.availTop ?? 0) : 0,
      // The screen's usable area: the extension uses it to look up where this screen really starts.
      availLeft: extended.availLeft ?? 0,
      availTop: extended.availTop ?? 0,
      availWidth: screen.availWidth,
      availHeight: screen.availHeight,
      isTopFrame,
    };
  };

  /** @param {MouseEvent} event */
  const position = (event) => ({ clientX: event.clientX, clientY: event.clientY, screenX: event.screenX, screenY: event.screenY });

  /**
   * Tells the extension something; its reply carries the recording's state. After the extension was
   * updated or removed, this copy of the script can never reach it again (Chrome throws at once), so it
   * stops listening for good.
   * @param {unknown} message
   */
  const send = (message) => {
    try {
      chrome.runtime.sendMessage(message).then(onCaptureState).catch(() => undefined);
    } catch {
      apply({ active: false, revision: Infinity });
    }
  };

  const flush = () => {
    if (timer) clearTimeout(timer);
    timer = 0;
    if (queue.length === 0) return;
    const events = queue;
    queue = [];
    // The reply carries the recording's state, so a page that missed its end stops here.
    send({ type: 'input', geometry: geometry(), events });
  };

  /** @param {unknown} event */
  const push = (event) => {
    queue.push(event);
    if (queue.length >= MAXIMUM_BATCH) flush();
    else if (!timer) timer = setTimeout(flush, FLUSH_MS);
  };

  /** @param {PointerEvent} event */
  const onMove = (event) => {
    if (event.timeStamp - lastMove < MOVE_INTERVAL_MS) return;
    lastMove = event.timeStamp;
    push({ kind: 'move', time: unixTime(event), ...position(event) });
  };

  /** @param {PointerEvent} event */
  const onDown = (event) => {
    const button = event.button === 0 ? 'left' : event.button === 2 ? 'right' : 'other';
    push({ kind: 'click', time: unixTime(event), button, ...position(event) });
    flush();
  };

  /** @param {EventTarget | null} target */
  const isPrivateField = (target) => {
    const element = target instanceof Element ? target : null;
    const field = element?.closest('input, textarea, [contenteditable]');
    if (!(field instanceof HTMLInputElement)) return false;
    return field.type === 'password' || /cc-|one-time-code|current-password|new-password/.test(field.autocomplete);
  };

  /**
   * The element that really has the keyboard focus. A field inside a web component sits in a shadow
   * root, open or closed, and the page only shows its host, so this looks inside.
   */
  const focusedElement = () => {
    let element = document.activeElement;
    while (element instanceof HTMLElement) {
      const inner = chrome.dom.openOrClosedShadowRoot(element)?.activeElement;
      if (!inner) break;
      element = inner;
    }
    return element;
  };

  /**
   * The key as you'd name it in a shortcut. With Option/Alt held, Macs turn letters into symbols
   * (⌥C types "ç"), so the physical key is used instead.
   * @param {KeyboardEvent} event
   */
  const keyName = (event) => {
    if (event.altKey && /^Key[A-Z]$/.test(event.code)) return event.code.slice(3).toLowerCase();
    if (event.altKey && /^Digit\d$/.test(event.code)) return event.code.slice(5);
    return event.key;
  };

  /** @param {KeyboardEvent} event */
  const onKey = (event) => {
    if (event.repeat || keystrokes === 'off' || MODIFIER_KEYS.has(event.key)) return;
    // The path starts at the field typed in, even inside an open shadow root; a closed one needs the focus.
    if (isPrivateField(event.composedPath()[0] ?? null) || isPrivateField(focusedElement())) return;
    const isShortcut = event.ctrlKey || event.altKey || event.metaKey || event.key === 'Escape' || /^F([1-9]|1\d|2[0-4])$/.test(event.key);
    if (keystrokes === 'shortcutsOnly' && !isShortcut) return;
    const key = keyName(event);
    if (!key || key === 'Unidentified' || key.length > 32) return;
    push({ kind: 'key', time: unixTime(event), key, modifiers: { control: event.ctrlKey, option: event.altKey, shift: event.shiftKey, command: event.metaKey } });
  };

  const listenerOptions = { capture: true, passive: true };

  /** @param {unknown} state */
  const apply = (state) => {
    const next = /** @type {{ active?: unknown, keystrokes?: unknown, revision?: unknown }} */ (state ?? {});
    if (typeof next.revision === 'number') {
      if (next.revision < revision) return;
      revision = next.revision;
    }
    keystrokes = next.keystrokes === 'off' || next.keystrokes === 'allKeys' ? next.keystrokes : 'shortcutsOnly';
    const shouldListen = next.active === true;
    if (shouldListen === isActive) return;
    isActive = shouldListen;
    if (isActive) {
      window.addEventListener('pointermove', onMove, listenerOptions);
      window.addEventListener('pointerdown', onDown, listenerOptions);
      window.addEventListener('keydown', onKey, listenerOptions);
    } else {
      window.removeEventListener('pointermove', onMove, listenerOptions);
      window.removeEventListener('pointerdown', onDown, listenerOptions);
      window.removeEventListener('keydown', onKey, listenerOptions);
      flush();
    }
  };

  /** News about the recording, broadcast or in a reply. Anything else is ignored. @param {unknown} message */
  const onCaptureState = (message) => {
    if (/** @type {{ type?: unknown } | null | undefined} */ (message)?.type === 'capture') apply(message);
  };

  chrome.runtime.onMessage.addListener(onCaptureState);
  // A page kept for the Back button hears no news while it's away: it stops listening as it leaves,
  // and asks again when it comes back.
  window.addEventListener('pagehide', (event) => {
    if (event.persisted) apply({ active: false, keystrokes, revision });
  });
  window.addEventListener('pageshow', (event) => {
    if (event.persisted) send({ type: 'capture-state' });
  });
  send({ type: 'capture-state' });
})();
