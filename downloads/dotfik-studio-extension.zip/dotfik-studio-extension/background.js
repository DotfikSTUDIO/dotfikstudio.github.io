// @ts-check
/**
 * Dotfik Studio extension: passes pointer, click and shortcut events from the tabs you record to the
 * studio tab on this computer, only while a recording runs. Nothing is sent anywhere else: the
 * extension has no permission or code to use the network.
 */

const STUDIO_PORT = 'dotfik-studio';
const CAPTURE_SCRIPT_ID = 'dotfik-capture';
const ALL_SITES = { origins: ['<all_urls>'] };
/**
 * When the studio page that started a take loses its connection, capture stops unless that same page
 * connects again within this time. It does after this background script restarts (within about 250 ms).
 */
const DISCONNECT_GRACE_MS = 3000;
/**
 * The studio says its take is still going every 20 seconds. If the take's page goes quiet for this
 * long (an error broke the page, or its stop got lost), capture stops even though the page is still
 * connected. Generous, because browsers slow down timers in background tabs.
 */
const QUIET_LIMIT_MS = 3 * 60_000;
/** Keys a "shortcuts only" take notes without Control, Option or Command, as capture.js decides. */
const LONE_SHORTCUT = /^(Escape|F([1-9]|1\d|2[0-4]))$/;
/** Where the studio itself lives on its site: only it may start a take, not the site's other pages. */
const STUDIO_PATH = /^\/studio(\/|$)/;

/** @typedef {'off' | 'shortcutsOnly' | 'allKeys'} KeystrokeMode */
/** @typedef {{ documentId: string, tabId: number }} CaptureOwner The studio page that started the take. */
/**
 * @typedef {object} CaptureState
 * @property {boolean} active
 * @property {KeystrokeMode} keystrokes
 * @property {CaptureOwner | null} owner
 * @property {number} revision Grows with every change, so a page told about changes out of order keeps the newest.
 * @property {number} stopsAt When capture stops (ms since 1970) unless the take's page is heard from first.
 */

/** @type {CaptureState} */
const IDLE = { active: false, keystrokes: 'shortcutsOnly', owner: null, revision: 0, stopsAt: 0 };

/** @type {Set<chrome.runtime.Port>} Pages of the studio's site currently connected (studio, home, privacy…). */
const studioPorts = new Set();
/** @type {CaptureState} The newest state. Also kept in chrome.storage.session, which outlives this script. */
let current = IDLE;
/** Whether you let the extension run in your tabs. Read again at start, at each take and whenever you change it. */
let hasAccess = false;
/** @type {ReturnType<typeof setTimeout> | undefined} */
let graceTimer;
/** @type {ReturnType<typeof setTimeout> | undefined} */
let quietTimer;
/** @type {chrome.system.display.DisplayUnitInfo[]} This computer's screens, kept ready so each event batch is fixed up at once, in order. */
let displays = [];
/** Capture changes run one at a time, in order, so a stop can never be overtaken by a start still under way. */
let captureQueue = Promise.resolve();

/**
 * Runs a capture change after the ones already queued. One that fails doesn't hold up the next.
 * Nothing in the queue may wait on a web page: a busy tab can take forever to answer.
 * @template T
 * @param {() => Promise<T>} task
 * @returns {Promise<T>}
 */
function queueCapture(task) {
  const run = captureQueue.then(task);
  captureQueue = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

/** @param {unknown} value @returns {KeystrokeMode} */
const keystrokeMode = (value) => (value === 'off' || value === 'allKeys' ? value : 'shortcutsOnly');

/** @param {unknown} value */
const finiteNumber = (value) => (typeof value === 'number' && Number.isFinite(value) ? value : 0);

/** @param {unknown} value @returns {CaptureOwner | null} */
function ownerFrom(value) {
  const owner = /** @type {{ documentId?: unknown, tabId?: unknown } | null} */ (typeof value === 'object' ? value : null);
  if (typeof owner?.documentId !== 'string' || typeof owner.tabId !== 'number') return null;
  return { documentId: owner.documentId, tabId: owner.tabId };
}

/** The state an earlier run of this script saved, checked field by field. @returns {Promise<CaptureState>} */
async function storedState() {
  const stored = /** @type {{ capture?: unknown }} */ (await chrome.storage.session.get('capture')).capture;
  const value = /** @type {Partial<Record<keyof CaptureState, unknown>>} */ (typeof stored === 'object' && stored !== null ? stored : {});
  return {
    active: value.active === true,
    keystrokes: keystrokeMode(value.keystrokes),
    owner: ownerFrom(value.owner),
    revision: finiteNumber(value.revision),
    // A take saved without a deadline counts as gone quiet.
    stopsAt: finiteNumber(value.stopsAt),
  };
}

/** Keeps the newest state where the next run of this script finds it. */
const saveState = () => chrome.storage.session.set({ capture: current });

/** A revision newer than every earlier one, even those this script never saw (the clock moves on). */
const nextRevision = () => Math.max(Date.now(), current.revision + 1);

/** What the listening script in a page needs to know (never which page owns the take). Without site access, nothing listens. */
const pageState = () => ({ type: 'capture', active: current.active && hasAccess, keystrokes: current.keystrokes, revision: current.revision });

function hasTabAccess() {
  return chrome.permissions.contains(ALL_SITES);
}

/** Site access as Chrome has it now; no answer counts as no access. */
const readAccess = () => hasTabAccess().catch(() => false);

/** The studio's own pages never report events (they are the recorder, not what's recorded). */
function studioMatches() {
  return chrome.runtime.getManifest().content_scripts?.find((script) => script.js?.includes('bridge.js'))?.matches ?? [];
}

async function registerCaptureScript() {
  if (!hasAccess) return;
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [CAPTURE_SCRIPT_ID] });
  if (existing.length > 0) return;
  await chrome.scripting.registerContentScripts([
    {
      id: CAPTURE_SCRIPT_ID,
      js: ['capture.js'],
      matches: ['<all_urls>'],
      excludeMatches: studioMatches(),
      runAt: 'document_start',
      allFrames: true,
      persistAcrossSessions: false,
    },
  ]);
}

async function unregisterCaptureScript() {
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [CAPTURE_SCRIPT_ID] });
  if (existing.length > 0) await chrome.scripting.unregisterContentScripts({ ids: [CAPTURE_SCRIPT_ID] });
}

/** Tabs showing one of the studio's own pages (their bridge script is connected here). */
const studioTabIds = () => new Set([...studioPorts].map((port) => port.sender?.tab?.id));

/** Tabs whose address is one of the studio's, matched by Chrome exactly as for the bridge script. */
async function studioTabsByAddress() {
  const patterns = studioMatches();
  if (patterns.length === 0) return [];
  return (await chrome.tabs.query({ url: patterns })).map((tab) => tab.id);
}

/** Tabs opened before the take get the capture script now, except the studio's own pages. */
async function injectIntoOpenTabs() {
  try {
    if (!hasAccess) return;
    const [tabs, byAddress] = await Promise.all([chrome.tabs.query({}), studioTabsByAddress()]);
    const skipped = new Set([...byAddress, ...studioTabIds()]);
    await Promise.allSettled(
      tabs
        .filter((tab) => tab.id !== undefined && !skipped.has(tab.id) && /^https?:/.test(tab.url ?? ''))
        .map((tab) => chrome.scripting.executeScript({ target: { tabId: /** @type {number} */ (tab.id), allFrames: true }, files: ['capture.js'] })),
    );
  } catch {
    // Chrome couldn't list the tabs: those already open aren't noted, pages loaded from now on are.
  }
}

/** @param {unknown} message */
async function broadcastToTabs(message) {
  try {
    const tabs = await chrome.tabs.query({});
    await Promise.allSettled(tabs.filter((tab) => tab.id !== undefined).map((tab) => chrome.tabs.sendMessage(/** @type {number} */ (tab.id), message)));
  } catch {
    // Chrome couldn't list the tabs. Events still arriving are dropped here, and every reply tells the page.
  }
}

/** @param {CaptureOwner} owner Whether the page that owns the take is connected here. */
const isConnected = (owner) => [...studioPorts].some((port) => port.sender?.documentId === owner.documentId);

/** Ends a take: pages stop listening and new pages no longer get the script. Never fails. */
async function stopCapture() {
  clearTimeout(graceTimer);
  clearTimeout(quietTimer);
  current = { ...IDLE, revision: nextRevision() };
  // From here on, events still arriving are dropped. Pages are told without waiting on them.
  void broadcastToTabs(pageState());
  // Both are tried even if the other fails. A script Chrome failed to remove still asks first and stays idle.
  await Promise.allSettled([unregisterCaptureScript(), saveState()]);
}

/** @param {number} stopsAt Ends the take, unless its page was heard from after this deadline was set. */
async function stopIfQuiet(stopsAt) {
  if (current.active && current.stopsAt === stopsAt) await stopCapture();
}

/** Capture stops unless the take's page is heard from within `milliseconds`. @param {number} milliseconds */
function armQuietTimer(milliseconds) {
  clearTimeout(quietTimer);
  const { stopsAt } = current;
  quietTimer = setTimeout(() => void queueCapture(() => stopIfQuiet(stopsAt)), milliseconds);
}

/**
 * Starts a take for the page that asked. If a step fails, everything is switched off again, so half
 * a start never stays behind (the take then simply has no pointer data).
 * @param {CaptureOwner} owner
 * @param {KeystrokeMode} keystrokes
 */
async function startCapture(owner, keystrokes) {
  // The page may have gone while earlier changes ran: a take that's already gone gets nothing.
  if (!isConnected(owner)) return;
  // A take belongs to its page until it ends: no other page can take it over, nor see its input.
  if (current.active && current.owner && current.owner.documentId !== owner.documentId) return;
  try {
    hasAccess = await readAccess();
    // The listening script only exists in your pages while a recording runs.
    await registerCaptureScript();
    current = { active: true, keystrokes, owner, revision: nextRevision(), stopsAt: Date.now() + QUIET_LIMIT_MS };
    await saveState();
  } catch {
    await stopCapture();
    return;
  }
  armQuietTimer(QUIET_LIMIT_MS);
  // Neither is waited for, so a busy tab can't hold up a stop. Pages ask for the state when they load.
  void broadcastToTabs(pageState());
  void injectIntoOpenTabs();
}

/** Ends the take if the page that started it is gone and hasn't come back. */
async function stopIfOwnerGone() {
  if (current.active && !(current.owner && isConnected(current.owner))) await stopCapture();
}

/** Gives the take's page DISCONNECT_GRACE_MS to come back before capture stops. */
function armGraceTimer() {
  clearTimeout(graceTimer);
  graceTimer = setTimeout(() => void queueCapture(stopIfOwnerGone), DISCONNECT_GRACE_MS);
}

/**
 * The take's page says it's still recording, so capture goes on for another QUIET_LIMIT_MS. Coming
 * back after this script restarted doesn't count: its bridge script reconnects even when the page is broken.
 * @param {chrome.runtime.Port} port
 */
async function heardFrom(port) {
  if (!current.active || current.owner?.documentId !== port.sender?.documentId) return;
  current = { ...current, stopsAt: Date.now() + QUIET_LIMIT_MS };
  armQuietTimer(QUIET_LIMIT_MS);
  // If this isn't saved, a restart of this script may end the take early, never late.
  await saveState().catch(() => undefined);
}

/**
 * A page of the site connected. The take's own page coming back (after this script restarted) keeps
 * capture on. Another page in the take's tab means it reloaded or navigated away: that take is gone.
 * Other pages change nothing. A hello always comes over a port that connected, so this covers it too.
 * @param {chrome.runtime.Port} port
 */
async function checkConnected(port) {
  const owner = current.active ? current.owner : null;
  const sender = port.sender;
  if (!owner || !sender) return;
  if (sender.documentId === owner.documentId) {
    clearTimeout(graceTimer);
    return;
  }
  // A page Chrome is only preparing out of sight (prerendering) hasn't replaced anything yet.
  const isShown = (sender.documentLifecycle ?? 'active') === 'active';
  if (sender.tab?.id === owner.tabId && isShown) await stopCapture();
}

/** @param {chrome.runtime.Port} port The take's own page lost its connection: give it a moment to come back. */
async function checkDisconnected(port) {
  const owner = current.active ? current.owner : null;
  if (owner && port.sender?.documentId === owner.documentId && !isConnected(owner)) armGraceTimer();
}

/** @param {chrome.runtime.Port} port */
function forget(port) {
  if (studioPorts.delete(port)) void queueCapture(() => checkDisconnected(port));
}

/** @param {chrome.runtime.Port} port @param {unknown} message */
function post(port, message) {
  try {
    port.postMessage(message);
  } catch {
    // The page went away: treat it as disconnected (it may own the take).
    forget(port);
  }
}

/** @param {unknown} message */
function sendToStudios(message) {
  for (const port of studioPorts) post(port, message);
}

/** Refreshes the list of screens. Without it, the pages' own numbers are passed on unchanged. */
async function refreshDisplays() {
  try {
    displays = await chrome.system.display.getInfo();
  } catch {
    displays = [];
  }
}

/** @param {chrome.system.display.Bounds} bounds @param {unknown} x @param {unknown} y */
const contains = (bounds, x, y) =>
  typeof x === 'number' && typeof y === 'number' && x >= bounds.left && x < bounds.left + bounds.width && y >= bounds.top && y < bounds.top + bounds.height;

/**
 * A page can only see where its screen's usable area starts (below the Mac menu bar, beside the Dock),
 * not where the screen itself starts. The screen with that usable area gives the real corner.
 * @param {unknown} geometry
 */
function withScreenOrigin(geometry) {
  if (typeof geometry !== 'object' || geometry === null) return geometry;
  const area = /** @type {{ availLeft?: unknown, availTop?: unknown, availWidth?: unknown, availHeight?: unknown }} */ (geometry);
  const display =
    displays.find(({ workArea: work }) => work.left === area.availLeft && work.top === area.availTop && work.width === area.availWidth && work.height === area.availHeight) ??
    // The list may be a moment out of date (the Dock just appeared): the screen containing that corner.
    displays.find(({ bounds }) => contains(bounds, area.availLeft, area.availTop));
  return display ? { ...geometry, screenLeft: display.bounds.left, screenTop: display.bounds.top } : geometry;
}

/**
 * Whether the take asked for this event: pointer events always, keys as its keystroke choice says.
 * A page that missed news (one kept for the Back button) may still note keys the way an earlier take
 * asked, so the choice is checked here again.
 * @param {unknown} event
 */
function isWanted(event) {
  const item = /** @type {{ kind?: unknown, key?: unknown, modifiers?: { control?: unknown, option?: unknown, command?: unknown } | null } | null} */ (
    typeof event === 'object' ? event : null
  );
  if (item?.kind !== 'key' || current.keystrokes === 'allKeys') return true;
  if (current.keystrokes === 'off') return false;
  const modifiers = item.modifiers;
  return modifiers?.control === true || modifiers?.option === true || modifiers?.command === true || (typeof item.key === 'string' && LONE_SHORTCUT.test(item.key));
}

/**
 * Passes a batch of events from a recorded tab to the page that owns the take, and to no one else.
 * Events from the studio's own tabs are dropped: they're the recorder, not what's recorded. Without
 * site access, nothing is passed on (pages that still listen stop at the reply).
 * @param {{ geometry?: unknown, events?: unknown }} message
 * @param {chrome.runtime.MessageSender} sender
 */
function forwardInput(message, sender) {
  const owner = current.active && hasAccess ? current.owner : null;
  const tabId = sender.tab?.id;
  if (!owner || tabId === undefined || studioTabIds().has(tabId) || !Array.isArray(message.events)) return;
  const events = message.events.filter(isWanted);
  if (events.length === 0) return;
  const input = { type: 'input', geometry: withScreenOrigin(message.geometry), events };
  for (const port of studioPorts) {
    if (port.sender?.documentId === owner.documentId) post(port, input);
  }
}

async function hello() {
  return { type: 'hello', version: chrome.runtime.getManifest().version, hasTabAccess: await hasTabAccess() };
}

/** @param {string | undefined} url Whether this is the studio itself, not another page of its site. */
function isStudioPage(url) {
  try {
    return STUDIO_PATH.test(new URL(url ?? '').pathname);
  } catch {
    return false;
  }
}

/**
 * Capture is always tied to the page that asked for it. A page Chrome can't name gets none, and so
 * does any page of the site other than the studio itself.
 * @param {chrome.runtime.Port} port
 * @param {unknown} requested
 */
function requestStart(port, requested) {
  const documentId = port.sender?.documentId;
  const tabId = port.sender?.tab?.id;
  if (typeof documentId !== 'string' || typeof tabId !== 'number' || !isStudioPage(port.sender?.url)) return;
  void refreshDisplays();
  void queueCapture(() => startCapture({ documentId, tabId }, keystrokeMode(requested)));
}

/**
 * Only the page that started the take can end it this way, so another studio tab can't cut it short.
 * Its own page closing, reloading, going away or going quiet still ends it (see checkConnected and the timers).
 * @param {chrome.runtime.Port} port
 */
async function stopRequestedBy(port) {
  if (current.active && current.owner && current.owner.documentId !== port.sender?.documentId) return;
  await stopCapture();
}

/**
 * @param {chrome.runtime.Port} port
 * @param {unknown} message
 */
async function handleStudioMessage(port, message) {
  if (typeof message !== 'object' || message === null) return;
  const { type } = /** @type {{ type?: unknown }} */ (message);
  if (type === 'hello') {
    post(port, await hello());
  } else if (type === 'capture-start') {
    requestStart(port, /** @type {{ keystrokes?: unknown }} */ (message).keystrokes);
  } else if (type === 'capture-stop') {
    void queueCapture(() => stopRequestedBy(port));
  } else if (type === 'keep-alive') {
    // Sent every 20 seconds during a take: it keeps this worker awake and shows the take's page still records.
    void queueCapture(() => heardFrom(port));
  } else if (type === 'open-access-page') {
    await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?page=access') });
  }
}

/**
 * This script just started (Chrome stops it when idle and starts it again for the next event). If a
 * take was running, its page must connect again within the grace period, or capture stops. The take
 * also still ends when its page goes quiet, counting the time this script was stopped.
 */
async function resume() {
  try {
    current = await storedState();
  } catch {
    // The saved state can't be read: switch everything off rather than guess.
    await stopCapture();
    return;
  }
  hasAccess = await readAccess();
  if (!current.active) return;
  const timeLeft = current.stopsAt - Date.now();
  if (timeLeft <= 0) {
    await stopCapture();
    return;
  }
  armGraceTimer();
  // More time left than a whole allowance means the clock was turned back: one allowance is the most.
  armQuietTimer(Math.min(timeLeft, QUIET_LIMIT_MS));
}

// First in the queue: every change below sees the state the last run of this script left.
void queueCapture(resume);
void refreshDisplays();

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== STUDIO_PORT) return;
  studioPorts.add(port);
  if (port.sender?.url) void chrome.storage.local.set({ studioUrl: new URL('/studio/', port.sender.url).href });
  // A page that went away meanwhile can't be answered, and nothing else depends on it.
  port.onMessage.addListener((message) => void handleStudioMessage(port, message).catch(() => undefined));
  port.onDisconnect.addListener(() => forget(port));
  void queueCapture(() => checkConnected(port));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'capture-state') {
    // Answered after any change already under way, so a page loading mid-change gets the outcome.
    void queueCapture(async () => sendResponse(pageState()));
    return true;
  }
  if (message?.type === 'input') {
    forwardInput(message, sender);
    // The reply lets a page that missed the end of a take stop listening at its next batch.
    sendResponse(pageState());
  }
  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void queueCapture(async () => {
    if (current.active && current.owner?.tabId === tabId) await stopCapture();
  });
});

chrome.system.display.onDisplayChanged.addListener(() => void refreshDisplays());

chrome.commands.onCommand.addListener((command) => {
  if (command !== 'toggle-recording' && command !== 'toggle-pause') return;
  if (studioPorts.size > 0) {
    sendToStudios({ type: 'command', command });
    return;
  }
  void chrome.storage.local.get('studioUrl').then(({ studioUrl }) => {
    if (typeof studioUrl === 'string') void chrome.tabs.create({ url: studioUrl });
  });
});

/** Tells the studio pages whether the extension may run in your tabs. */
async function sendAccess() {
  sendToStudios({ type: 'access', hasTabAccess: await hasTabAccess() });
}

/**
 * You changed the extension's site access (in Chrome's menu or the popup). During a take, pages are
 * told at once, with a new revision: without access, those already listening stop (and their events
 * are dropped meanwhile); with it, they listen again and open tabs get the script.
 */
async function accessChanged() {
  hasAccess = await readAccess();
  // Without site access Chrome can't run the script anyway, so a removal that fails changes nothing.
  if (!hasAccess) await unregisterCaptureScript().catch(() => undefined);
  if (!current.active) return;
  current = { ...current, revision: nextRevision() };
  void broadcastToTabs(pageState());
  if (hasAccess) {
    // If Chrome refuses, pages opened from now on just aren't noted during this take.
    await registerCaptureScript().catch(() => undefined);
    void injectIntoOpenTabs();
  }
  await saveState().catch(() => undefined);
}

const onAccessChange = () => {
  void queueCapture(accessChanged);
  void sendAccess();
};
chrome.permissions.onAdded.addListener(onAccessChange);
chrome.permissions.onRemoved.addListener(onAccessChange);

chrome.runtime.onInstalled.addListener(({ reason }) => {
  // A fresh start: nothing is being recorded, so nothing listens in your pages.
  void queueCapture(stopCapture);
  if (reason === 'install') void chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?page=welcome') });
});

chrome.runtime.onStartup.addListener(() => void queueCapture(stopCapture));

export {};
