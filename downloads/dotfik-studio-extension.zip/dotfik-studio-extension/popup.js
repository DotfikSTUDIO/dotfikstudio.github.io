// @ts-check
const ALL_SITES = { origins: ['<all_urls>'] };
const params = new URLSearchParams(window.location.search);
const isPage = params.has('page');

/** @param {string} id */
const element = (id) => {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Missing #${id}`);
  return found;
};

// The product's name comes from the manifest, which the package script fills in from the website's
// settings. The toolbar button's title is the plain name; the store's copy has a longer listing name.
const manifest = chrome.runtime.getManifest();
const brandName = manifest.action?.default_title ?? manifest.name;
document.title = brandName;
element('brand-name').textContent = brandName;
for (const span of document.querySelectorAll('.brand-name')) span.textContent = brandName;

if (isPage) document.body.classList.add('page');
if (params.get('page') === 'welcome') element('welcome').hidden = false;

async function showAccess() {
  const allowed = await chrome.permissions.contains(ALL_SITES);
  element('access-text').textContent = allowed ? 'On. Clicks in the tabs you record are used for zooms.' : 'Off. Allow it to get automatic zooms and click effects.';
  element('allow').hidden = allowed;
  element('access-explain').hidden = allowed && !isPage;
}

async function showCapture() {
  const { capture } = /** @type {{ capture?: { active?: boolean } }} */ (await chrome.storage.session.get('capture'));
  element('capture-text').textContent = capture?.active ? 'A recording is running. Pointer and clicks are being noted.' : 'Not recording.';
}

async function showShortcuts() {
  const commands = await chrome.commands.getAll();
  const key = (/** @type {string} */ name) => commands.find((command) => command.name === name)?.shortcut || 'not set';
  element('shortcut-text').textContent = `Stop: ${key('toggle-recording')} · Pause: ${key('toggle-pause')}`;
}

async function showStudio() {
  const { studioUrl } = await chrome.storage.local.get('studioUrl');
  element('studio-missing').hidden = typeof studioUrl === 'string';
  /** @type {HTMLButtonElement} */ (element('open-studio')).disabled = typeof studioUrl !== 'string';
}

element('allow').addEventListener('click', async () => {
  // Chrome shows its own permission prompt; nothing changes unless you accept it there.
  await chrome.permissions.request(ALL_SITES).catch(() => false);
  await showAccess();
});

element('shortcuts').addEventListener('click', () => void chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));

element('open-studio').addEventListener('click', async () => {
  const { studioUrl } = await chrome.storage.local.get('studioUrl');
  if (typeof studioUrl === 'string') await chrome.tabs.create({ url: studioUrl });
  if (!isPage) window.close();
});

chrome.storage.onChanged.addListener(() => void showCapture());
void showAccess();
void showCapture();
void showShortcuts();
void showStudio();

export {};
