// @ts-check
/**
 * Runs only on the Dotfik Studio site. Carries messages between the studio page and the extension,
 * inside this browser.
 */
(() => {
  const PAGE = 'dotfik-studio-page';
  const EXTENSION = 'dotfik-studio-extension';
  const RECONNECT_MS = 250;
  /** @type {chrome.runtime.Port | null} */
  let port = null;
  let isGone = false;

  /** @returns {chrome.runtime.Port | null} */
  const connect = () => {
    if (isGone) return null;
    try {
      port = chrome.runtime.connect({ name: 'dotfik-studio' });
    } catch {
      // The extension was removed or updated; this page needs a reload to talk to it again.
      isGone = true;
      port = null;
      return null;
    }
    port.onMessage.addListener((message) => {
      window.postMessage({ ...message, source: EXTENSION }, window.location.origin);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      setTimeout(() => {
        if (!port) connect();
      }, RECONNECT_MS);
    });
    return port;
  };

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (typeof data !== 'object' || data === null || data.source !== PAGE || typeof data.type !== 'string') return;
    const { source: _source, ...message } = data;
    try {
      (port ?? connect())?.postMessage(message);
    } catch {
      port = null;
    }
  });

  connect();
})();
